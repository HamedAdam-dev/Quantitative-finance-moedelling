# Frontend (React + Vite)

See the [repository root README](../README.md) for setup, GitHub Pages, and backend instructions.

```bash
npm install
npm run dev
```

Build (used by GitHub Actions):

```bash
VITE_BASE=/Quant-modelling/ npm run build
```
